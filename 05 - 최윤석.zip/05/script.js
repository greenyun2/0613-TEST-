let url = "https://jsonplaceholder.typicode.com/comments"; 

fetch(url)
  .then(response => response.json())
  .then(json => {
    const formattedJson = JSON.stringify(json, null, 2);
    document.querySelector("#log").innerText = formattedJson;
  })
  .catch(error => console.error(error));