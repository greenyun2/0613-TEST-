import {str1, str2} from `./MyClass1`

document.querySelector("#log").innerHTML = `
<p>${str1}</p>
<p>${str2}</p>
`

