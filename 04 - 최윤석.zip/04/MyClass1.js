export const str1 = "오늘은 기분좋은 날이에요!"
export const str2 = "항상 그렇듯 늘 파이팅 입니다!"

