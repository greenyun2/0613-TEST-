const btnSave = document.querySelector('.btnSave');
const input = document.querySelector('input');
const h1 = document.querySelector('h1');
const btnRemove = document.querySelector('.btnRemove');
const btnClear = document.querySelector('.btnClear');



btnSave.addEventListener('click', () => {
  const value = input.value;
  localStorage.setItem('data', value);
});

btnRemove.addEventListener('click', () => {
  localStorage.removeItem('data');
})

btnClear.addEventListener('click', () => {
  localStorage.clear();
})